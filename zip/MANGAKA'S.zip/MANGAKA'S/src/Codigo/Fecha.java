/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Codigo;

import java.util.Calendar;
import java.util.GregorianCalendar;
/**
 *
 * @author WORKSTATION
 */
public class Fecha {
    
    Calendar fecha= new GregorianCalendar();
    String ano=Integer.toString(fecha.get(Calendar.YEAR));
    String mes=Integer.toString(fecha.get(Calendar.MONTH)+1);
    String dia=Integer.toString(fecha.get(Calendar.DATE));
    
    String fechacomp=dia+"/"+mes+"/"+ano;
}
