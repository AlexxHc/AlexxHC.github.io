/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Codigo;

import javax.swing.ImageIcon;
import java.awt.Image;
import javax.swing.JOptionPane;
import java.text.DecimalFormat;
//base de datos
import java.awt.HeadlessException;
import java.sql.*;

/**
 *
 * @author Jacob
 */
public class frmTicket extends javax.swing.JFrame {

    int id,idpe;
    String nombre,tel,dom,mp,nmanga,fecha,correo,precio,cant,cenvio;
    ImageIcon Cromo = new ImageIcon();
    ImageIcon Escala = new ImageIcon();
    DecimalFormat df=new DecimalFormat("#.00");
    
    MangaClase you=new MangaClase();
    Connection cn=you.con();
    /**
     * Creates new form frmTicket
     */
    public frmTicket() {
        initComponents();
        
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/trueno.png"));
        this.setIconImage(Cromo.getImage());
        
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/foon.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblFon.getWidth(),
                lblFon.getHeight(),Image.SCALE_DEFAULT));
        lblFon.setIcon(Escala);
        
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/catalogo.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(btnCatalogo.getWidth(),
                btnCatalogo.getHeight(),Image.SCALE_DEFAULT));
        btnCatalogo.setIcon(Escala);
        
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/inicio.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(btnInicio.getWidth(),
                btnInicio.getHeight(),Image.SCALE_DEFAULT));
        btnInicio.setIcon(Escala);
        
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/carrito.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(btnPedido.getWidth(),
                btnPedido.getHeight(),Image.SCALE_DEFAULT));
        btnPedido.setIcon(Escala);
        
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/salir.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(btnSalir.getWidth(),
                btnSalir.getHeight(),Image.SCALE_DEFAULT));
        btnSalir.setIcon(Escala);
        
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/Banner2.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblPan1.getWidth(),
                lblPan1.getHeight(),Image.SCALE_DEFAULT));
        lblPan1.setIcon(Escala);
        
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/Banner1.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblPan2.getWidth(),
                lblPan2.getHeight(),Image.SCALE_DEFAULT));
        lblPan2.setIcon(Escala);
        
        //consulta a cliente
        
        id=Integer.parseInt(JOptionPane.showInputDialog(null,"Dame el id de tu cuenta:"));
        try{
        PreparedStatement pst = cn.prepareStatement("select nombre_completo, telefono, domicilio, correo "
                    + "from cliente where id= ?");
            pst.setInt(1, id);
            ResultSet rs= pst.executeQuery();
            
            if(rs.next())
            {
                nombre=rs.getString("nombre_completo");
                tel=rs.getString("telefono");
                dom=rs.getString("domicilio");
                correo=rs.getString("correo");
                
                
            }
            }
            catch(HeadlessException | SQLException ex)
                    {
                    JOptionPane.showMessageDialog(null, "El ID de la cuenta es Incorrecto");
                    }
        
        //consulta a pedido
        idpe=Integer.parseInt(JOptionPane.showInputDialog(this,"Dame el id de tu pedido:"));
        try
            {
                
            PreparedStatement pst = cn.prepareStatement("select nom_manga, precio, cantidad, costo_envio "
                    + "from pedido where id_pedido= ?");
            pst.setInt(1, idpe);
            ResultSet rs= pst.executeQuery();
            
            if(rs.next())
            {
                nmanga=rs.getString("nom_manga");
                precio=rs.getString("precio");
                cant=rs.getString("cantidad");
                cenvio=rs.getString("costo_envio");
                
            }
            }
            catch(HeadlessException | SQLException ex)
                    {
                    JOptionPane.showMessageDialog(null, "El ID del Pedido es Incorrecto");
                    }
        

        //Ticket: Nombre, Contacto, direccion, cantidad,costo envio, metodo pago, fecha, subtotal, total
        
        
        txtaTicket.setText("                                     MANGAKA'S Ticket\n"
                + "             Nombre del Cliente: "+nombre
                + "\n             Direccion de Envio: "+dom
                + "\n             Numero de Contacto: "+tel
                + "\n             Manga: "+nmanga
                + "\n             Estado: Disponible"
                + "\n             Cantidad Pedida: "+cant
                + "\n             Precio Inicial: "+precio
                + "\n             Costo de Envio: "+cenvio
                + "\n             ¡GRACIAS POR SU PREFERENCIA!");
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/fondot.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblLogo.getWidth(),
                lblLogo.getHeight(),Image.SCALE_DEFAULT));
        lblLogo.setIcon(Escala);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        lblPan1 = new javax.swing.JLabel();
        lblPan2 = new javax.swing.JLabel();
        panTicket = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        lblLogo = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtaTicket = new javax.swing.JTextArea();
        btnCatalogo = new javax.swing.JButton();
        btnInicio = new javax.swing.JButton();
        btnPedido = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        lblFon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoCat.png"))); // NOI18N
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 620, 140, 70));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoCat.png"))); // NOI18N
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 10, 140, 70));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoCat.png"))); // NOI18N
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 620, 140, 70));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoCat.png"))); // NOI18N
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 140, 70));
        getContentPane().add(lblPan1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 160, 530));
        getContentPane().add(lblPan2, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 90, 160, 530));

        panTicket.setBackground(new java.awt.Color(255, 255, 255));
        panTicket.setOpaque(false);
        panTicket.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel3.setText("***TICKET COMPRA***");
        panTicket.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 10, -1, 50));
        panTicket.add(lblLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 390, 330, 260));

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        txtaTicket.setEditable(false);
        txtaTicket.setColumns(20);
        txtaTicket.setFont(new java.awt.Font("Gadugi", 1, 14)); // NOI18N
        txtaTicket.setRows(5);
        jScrollPane1.setViewportView(txtaTicket);

        panTicket.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 400, 610));

        getContentPane().add(panTicket, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 0, 460, 680));

        btnCatalogo.setBackground(new java.awt.Color(0, 0, 0));
        btnCatalogo.setToolTipText("Regresar al Catalogo");
        btnCatalogo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnCatalogo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCatalogo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCatalogoActionPerformed(evt);
            }
        });
        getContentPane().add(btnCatalogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 140, 80, 80));

        btnInicio.setBackground(new java.awt.Color(0, 0, 0));
        btnInicio.setToolTipText("Regresar al Inicio");
        btnInicio.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnInicio.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInicioActionPerformed(evt);
            }
        });
        getContentPane().add(btnInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 280, 80, 80));

        btnPedido.setBackground(new java.awt.Color(0, 0, 0));
        btnPedido.setToolTipText("Continuar Comprando");
        btnPedido.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnPedido.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPedidoActionPerformed(evt);
            }
        });
        getContentPane().add(btnPedido, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 410, 80, 80));

        btnSalir.setBackground(new java.awt.Color(0, 0, 0));
        btnSalir.setToolTipText("Finalizar Pedido y Salir");
        btnSalir.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnSalir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        getContentPane().add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 540, 80, 80));

        lblFon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/FonCat.png"))); // NOI18N
        getContentPane().add(lblFon, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 710));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInicioActionPerformed
        // TODO add your handling code here:
        dispose();
        new frmCatalogo().setVisible(true);
    }//GEN-LAST:event_btnInicioActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnCatalogoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCatalogoActionPerformed
        // TODO add your handling code here:
        dispose();
        new frmCatalogo().setVisible(true);
    }//GEN-LAST:event_btnCatalogoActionPerformed

    private void btnPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPedidoActionPerformed
        // TODO add your handling code here:
        dispose();
        new frmPedido().setVisible(true);
    }//GEN-LAST:event_btnPedidoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmTicket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmTicket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmTicket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmTicket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmTicket().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCatalogo;
    private javax.swing.JButton btnInicio;
    private javax.swing.JButton btnPedido;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblFon;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JLabel lblPan1;
    private javax.swing.JLabel lblPan2;
    private javax.swing.JPanel panTicket;
    private javax.swing.JTextArea txtaTicket;
    // End of variables declaration//GEN-END:variables
}
