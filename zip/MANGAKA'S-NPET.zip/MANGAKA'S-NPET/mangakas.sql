drop database mangakas;
CREATE DATABASE mangakas;
use mangakas;

create table cliente
(
id int auto_increment primary key not null,
nombre_completo varchar(45) not null,
telefono varchar(20) not null,
domicilio varchar(60) not null,
fecha_nacimiento varchar(20) not null,
correo varchar(40) unique not null,
contrasena varchar(20) not null
);

drop table pago;
create table pago
(
id_pago int auto_increment primary key not null,
metodo_pago varchar(40),
fecha_pago varchar(20)
);

drop table pedido;
create table pedido
(
id_pedido int auto_increment primary key not null,
nom_manga varchar(45) not null,
precio varchar(45) not null,
cantidad int(5) not null,
costo_envio varchar(45),
estado varchar(45) not null,
correo varchar(40) not null,
foreign key (correo) references cliente(correo)
);

create table ticket
(
id_ticket int auto_increment primary key not null,
cantidad int(5),
subtotal decimal (10,2),
total decimal (10,2),
id_pedido int not null,
foreign key (id_pedido) references cliente(id_pedido)
);

select * from cliente;
select * from pedido;
select * from pago;