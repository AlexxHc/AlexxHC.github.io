/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Codigo;

import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;


/**
 *
 * @author WORKSTATION
 */
public class frmCatalogo extends javax.swing.JFrame {
    ImageIcon Cromo = new ImageIcon();
    ImageIcon Escala = new ImageIcon();
    String nomM;
    /**
     * Creates new form frmCatalogo
     */
    public frmCatalogo() {
        initComponents();
        
        setIconImage(new ImageIcon(getClass().getResource("/Imagenes/trueno.png")).getImage());
        
        btnTenkuu.setFocusPainted(false);
        btnTenkuu.setContentAreaFilled(false);
        btnShin.setFocusPainted(false);
        btnShin.setContentAreaFilled(false);
        btnTokyo.setFocusPainted(false);
        btnTokyo.setContentAreaFilled(false);
        btnBlue.setFocusPainted(false);
        btnBlue.setContentAreaFilled(false);
        btnBerserk.setFocusPainted(false);
        btnBerserk.setContentAreaFilled(false);
        btnKimetsu.setFocusPainted(false);
        btnKimetsu.setContentAreaFilled(false);
        btnShuu.setFocusPainted(false);
        btnShuu.setContentAreaFilled(false);
        btnOverlord.setFocusPainted(false);
        btnOverlord.setContentAreaFilled(false);
        btnYoukoso.setFocusPainted(false);
        btnYoukoso.setContentAreaFilled(false);
        btnBlack.setFocusPainted(false);
        btnBlack.setContentAreaFilled(false);
        btnOne.setFocusPainted(false);
        btnOne.setContentAreaFilled(false);
        btnMushoku.setFocusPainted(false);
        btnMushoku.setContentAreaFilled(false);
        btnBoku.setFocusPainted(false);
        btnBoku.setContentAreaFilled(false);
        btnGoblin.setFocusPainted(false);
        btnGoblin.setContentAreaFilled(false);
        btnTsuki.setFocusPainted(false);
        btnTsuki.setContentAreaFilled(false);
        
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/trueno.png"));
        this.setIconImage(Cromo.getImage());
        
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/Sal.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(btnSalir.getWidth(),
                btnSalir.getHeight(),Image.SCALE_DEFAULT));
        btnSalir.setIcon(Escala);
        
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/carrito.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(btnPedido.getWidth(),
                btnPedido.getHeight(),Image.SCALE_DEFAULT));
        btnPedido.setIcon(Escala);
        
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/foon.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblFon.getWidth(),
                lblFon.getHeight(),Image.SCALE_DEFAULT));
        lblFon.setIcon(Escala);
        
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/inicio.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(btnInicio.getWidth(),
                btnInicio.getHeight(),Image.SCALE_DEFAULT));
        
        btnInicio.setIcon(Escala);
        pnlDesc.setVisible(false);
        
        Cromo= new ImageIcon(getClass().getResource("/Imagenes/fonññ.jpg"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblFDesc.getWidth(),
                lblFDesc.getHeight(),Image.SCALE_DEFAULT));
        lblFDesc.setIcon(Escala);
        
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/fondoMangas.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblFonDesc.getWidth(),
                lblFonDesc.getHeight(),Image.SCALE_DEFAULT));
        lblFonDesc.setIcon(Escala);
        
        //Imagenes de Portada de Mangas
        
        //Portada de Tenkuu
        Cromo=new ImageIcon(getClass().getResource("/Imagenes/MTenkuu.png"));
        Escala=new ImageIcon(Cromo.getImage().getScaledInstance(lblTenkuu.getWidth(),
                lblTenkuu.getHeight(),Image.SCALE_DEFAULT));
        lblTenkuu.setIcon(Escala);
        
        //Portada de Shingeki
        Cromo=new ImageIcon(getClass().getResource("/Imagenes/MShingeki.jpg"));
        Escala=new ImageIcon(Cromo.getImage().getScaledInstance(lblShin.getWidth(),
                lblShin.getHeight(),Image.SCALE_DEFAULT));
        lblShin.setIcon(Escala);
        
        //Portada de Tokyo Ghoul Re: Vol.9
        Cromo=new ImageIcon(getClass().getResource("/Imagenes/MTokyo.png"));
        Escala=new ImageIcon(Cromo.getImage().getScaledInstance(lblTokyo.getWidth(),
                lblTokyo.getHeight(),Image.SCALE_DEFAULT));
        lblTokyo.setIcon(Escala);
        //Portada de Berserk 
        Cromo=new ImageIcon(getClass().getResource("/Imagenes/MBerserk.png"));
        Escala=new ImageIcon(Cromo.getImage().getScaledInstance(lblBerserk.getWidth(),
                lblBerserk.getHeight(),Image.SCALE_DEFAULT));
        lblBerserk.setIcon(Escala);
        
        //Portada de Black Clover
        Cromo=new ImageIcon(getClass().getResource("/Imagenes/MBlack.png"));
        Escala=new ImageIcon(Cromo.getImage().getScaledInstance(lblBlack.getWidth(),
                lblBlack.getHeight(),Image.SCALE_DEFAULT));
        lblBlack.setIcon(Escala);
        
        //Portada de Blue Lock
        Cromo=new ImageIcon(getClass().getResource("/Imagenes/MBlue.png"));
        Escala=new ImageIcon(Cromo.getImage().getScaledInstance(lblBlue.getWidth(),
                lblBlue.getHeight(),Image.SCALE_DEFAULT));
        lblBlue.setIcon(Escala);
        
        //Portada de Boku no Hero
        Cromo=new ImageIcon(getClass().getResource("/Imagenes/MBoku.jpg"));
        Escala=new ImageIcon(Cromo.getImage().getScaledInstance(lblBoku.getWidth(),
                lblBoku.getHeight(),Image.SCALE_DEFAULT));
        lblBoku.setIcon(Escala);
        
        //Portada de Goblin Slayer
        Cromo=new ImageIcon(getClass().getResource("/Imagenes/MGoblin.png"));
        Escala=new ImageIcon(Cromo.getImage().getScaledInstance(lblGoblin.getWidth(),
                lblGoblin.getHeight(),Image.SCALE_DEFAULT));
        lblGoblin.setIcon(Escala);
        
        //Portada de Kimetsu no Yaiba
        Cromo=new ImageIcon(getClass().getResource("/Imagenes/MKimetsu.png"));
        Escala=new ImageIcon(Cromo.getImage().getScaledInstance(lblKimetsu.getWidth(),
                lblKimetsu.getHeight(),Image.SCALE_DEFAULT));
        lblKimetsu.setIcon(Escala);
        
        //Portada de Mushoku Tensei
        Cromo=new ImageIcon(getClass().getResource("/Imagenes/MMushoku.jpg"));
        Escala=new ImageIcon(Cromo.getImage().getScaledInstance(lblMushoku.getWidth(),
                lblMushoku.getHeight(),Image.SCALE_DEFAULT));
        lblMushoku.setIcon(Escala);
        
        //Portada de One Punch Man
        Cromo=new ImageIcon(getClass().getResource("/Imagenes/MOne.jpg"));
        Escala=new ImageIcon(Cromo.getImage().getScaledInstance(lblOne.getWidth(),
                lblOne.getHeight(),Image.SCALE_DEFAULT));
        lblOne.setIcon(Escala);
        
        //Portada de Overlord
        Cromo=new ImageIcon(getClass().getResource("/Imagenes/MOverlord.png"));
        Escala=new ImageIcon(Cromo.getImage().getScaledInstance(lblOverlord.getWidth(),
                lblOverlord.getHeight(),Image.SCALE_DEFAULT));
        lblOverlord.setIcon(Escala);
        
        //Portada de Shuumatsu no Valkyrie
        Cromo=new ImageIcon(getClass().getResource("/Imagenes/MShuumatsu.png"));
        Escala=new ImageIcon(Cromo.getImage().getScaledInstance(lblShuu.getWidth(),
                lblShuu.getHeight(),Image.SCALE_DEFAULT));
        lblShuu.setIcon(Escala);
        
        //Portada de Tsuki Michibiku
        Cromo=new ImageIcon(getClass().getResource("/Imagenes/MTsuki.jpg"));
        Escala=new ImageIcon(Cromo.getImage().getScaledInstance(lblTsuki.getWidth(),
                lblTsuki.getHeight(),Image.SCALE_DEFAULT));
        lblTsuki.setIcon(Escala);
        
        //Portada de Youkoso 
        Cromo=new ImageIcon(getClass().getResource("/Imagenes/MYoukoso.jpeg"));
        Escala=new ImageIcon(Cromo.getImage().getScaledInstance(lblYoukoso.getWidth(),
                lblYoukoso.getHeight(),Image.SCALE_DEFAULT));
        lblYoukoso.setIcon(Escala);
        //Informacion de los Mangas
        
        //Informacion de Tenkuu
        txtaTenkuu.setText("Autor: Tsuina Miura\n"
                + "Generos: Acción, Horror, Misterio, Drama, Shounen\n"
                + "Editorial: Panini\n"
                + "Estado: Publicandose\n"
                + "No. de páginas: 192");
        
        
        txtaShingeki.setText("Autor: Hajime Isayama\n"
                + "Generos: Horror, Drama, Shounen\n"
                + "Editorial: Panini\n"
                + "Estado: Finalizado\n"
                + "No. de páginas: 200");
        
        
        txtaTokyo.setText("Autor: Sui Ishida\n"
                + "Generos: Acción, Sobrenatural, Horror, Drama, Misterio,\n Psicológico.\n"
                + "Editorial: Panini\n"
                + "Estado: Finalizado\n"
                + "No. de páginas: 200");
        
        
        txtaBlue.setText("Autor: Kaneshiro Muneyuki\n"
                + "Generos: Shuonen, Deportes\n"
                + "Editorial: Panini\n"
                + "Estado: Publicandose\n"
                + "No. de páginas: 192");
        
        
        txtaBerserk.setText("Autor: Kentarou Miura\n"
                + "Generos: Acción, Sobrenatural, Horror, Drama, Aventura,\nFantasía, Psicológico, "
                + "Romance, Tragedia.\n"
                + "Editorial: Panini\n"
                + "Estado: Publicandose\n"
                + "No. de páginas: 224");
        
        
        txtaKimetsu.setText("Autor: Koyoharu Gotoge\n"
                + "Generos: Acción, Sobrenatural, Shuonen, Escolares\n"
                + "Editorial: Panini\n"
                + "Estado: Finalizado\n"
                + "No. de páginas: 192");
        
        
        txtaShuu.setText("Autor: Sui Ishida\n"
                + "Generos: Acción, Sobrenatural, Fantasía, Histórico, \nArtes Marciales.\n"
                + "Editorial: Panini\n"
                + "Estado: Publicandose\n"
                + "No. de páginas: 200");
        
        
        txtaOverlord.setText("Autor: Maruyama Kugane\n"
                + "Generos: Acción, Sobrenatural, Fantasía, Comedia\n"
                + "Editorial: Panini\n"
                + "Estado: Publicandose\n"
                + "No. de páginas: 210");
        
        
        txtaYoukoso.setText("Autores:  Ichino Yuyu, Syougo Kinugasa\n"
                + "Generos: Drama, Escolares, Suspenso, Psicológico\n"
                + "Editorial: Panini\n"
                + "Estado: Publicandose\n"
                + "No. de páginas: 148");
        
        
        txtaBlack.setText("Autor: Yuki Tabata\n"
                + "Generos: Acción, Comedia, Fantasía, Shounen, Magia\n"
                + "Editorial: Panini\n"
                + "Estado: Publicandose\n"
                + "No. de páginas: 184");
        
        
        txtaOne.setText("Autor: One\n"
                + "Generos: Acción,Comedia, Seinen, Sobrenatural, Superpoderes\n"
                + "Editorial: Panini\n"
                + "Estado: Publicandose\n"
                + "No. de páginas: 216");
        
        
        txtaMushoku.setText("Autor: Rifujin Na Magonote\n"
                + "Generos: Acción, Aventura, Comedia, Harem, \nFantasía, Romance, Magia.\n"
                + "Editorial: Panini\n"
                + "Estado: Publicandose\n"
                + "No. de páginas: 180");
        
        txtaBoku.setText("Autor: Horikoshi Kouhei\n"
                + "Generos: Acción, Comedia, Escolares, Shounen, Superpoderes\n"
                + "Editorial: Panini\n"
                + "Estado: Publicandose\n"
                + "No. de páginas: 200");
        
        txtaGoblin.setText("Autor: Kagyu Kumo\n"
                + "Generos: Acción, Aventura, Fantasía, Drama, Horror, Seinen.\n"
                + "Editorial: Panini\n"
                + "Estado: Publicandose\n"
                + "No. de páginas: 178");
        
        
        txtaTsuki.setText("Autor: Azumi Kei\n"
                + "Generos: Acción, Aventura, Comedia, Fantasía, Harem,\nRomance, Shounen.\n"
                + "Editorial: Panini\n"
                + "Estado: Publicandose\n"
                + "No. de páginas: 192");
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnSalir = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        scrlMangas = new javax.swing.JScrollPane();
        pnlMangas = new javax.swing.JPanel();
        pnlTenkuu = new javax.swing.JPanel();
        btnTenkuu = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtaTenkuu = new javax.swing.JTextArea();
        jLabel11 = new javax.swing.JLabel();
        lblTenkuu = new javax.swing.JLabel();
        pnlShin = new javax.swing.JPanel();
        btnShin = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtaShingeki = new javax.swing.JTextArea();
        jLabel16 = new javax.swing.JLabel();
        lblShin = new javax.swing.JLabel();
        pnlTokyo = new javax.swing.JPanel();
        btnTokyo = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtaTokyo = new javax.swing.JTextArea();
        lblTokyo = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        pnlBlue = new javax.swing.JPanel();
        btnBlue = new javax.swing.JButton();
        jScrollPane7 = new javax.swing.JScrollPane();
        txtaBlue = new javax.swing.JTextArea();
        lblBlue = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        pnlBerserk = new javax.swing.JPanel();
        btnBerserk = new javax.swing.JButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        txtaBerserk = new javax.swing.JTextArea();
        lblBerserk = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        pnlKimetsu = new javax.swing.JPanel();
        btnKimetsu = new javax.swing.JButton();
        jScrollPane9 = new javax.swing.JScrollPane();
        txtaKimetsu = new javax.swing.JTextArea();
        lblKimetsu = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        pnlShuu = new javax.swing.JPanel();
        btnShuu = new javax.swing.JButton();
        jScrollPane10 = new javax.swing.JScrollPane();
        txtaShuu = new javax.swing.JTextArea();
        lblShuu = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        pnlOverlord = new javax.swing.JPanel();
        btnOverlord = new javax.swing.JButton();
        jScrollPane11 = new javax.swing.JScrollPane();
        txtaOverlord = new javax.swing.JTextArea();
        lblOverlord = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        pnlYoukoso = new javax.swing.JPanel();
        btnYoukoso = new javax.swing.JButton();
        jScrollPane12 = new javax.swing.JScrollPane();
        txtaYoukoso = new javax.swing.JTextArea();
        lblYoukoso = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        pnlBlack = new javax.swing.JPanel();
        btnBlack = new javax.swing.JButton();
        jScrollPane13 = new javax.swing.JScrollPane();
        txtaBlack = new javax.swing.JTextArea();
        lblBlack = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        pnlOne = new javax.swing.JPanel();
        btnOne = new javax.swing.JButton();
        jScrollPane14 = new javax.swing.JScrollPane();
        txtaOne = new javax.swing.JTextArea();
        lblOne = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        pnlMushoku = new javax.swing.JPanel();
        btnMushoku = new javax.swing.JButton();
        jScrollPane15 = new javax.swing.JScrollPane();
        txtaMushoku = new javax.swing.JTextArea();
        lblMushoku = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        pnlBoku = new javax.swing.JPanel();
        btnBoku = new javax.swing.JButton();
        jScrollPane16 = new javax.swing.JScrollPane();
        txtaBoku = new javax.swing.JTextArea();
        lblBoku = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        pnlGoblin = new javax.swing.JPanel();
        btnGoblin = new javax.swing.JButton();
        jScrollPane17 = new javax.swing.JScrollPane();
        txtaGoblin = new javax.swing.JTextArea();
        lblGoblin = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        pnlTsuki = new javax.swing.JPanel();
        btnTsuki = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        txtaTsuki = new javax.swing.JTextArea();
        lblTsuki = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        pnlMenu = new javax.swing.JPanel();
        btnInicio = new javax.swing.JButton();
        cboCat = new javax.swing.JComboBox<>();
        btnPedido = new javax.swing.JButton();
        pnlDesc = new javax.swing.JPanel();
        lblFotoM = new javax.swing.JLabel();
        lblNomM = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtaDesc = new javax.swing.JTextArea();
        lblFDesc = new javax.swing.JLabel();
        lblFonDesc = new javax.swing.JLabel();
        lblFon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnSalir.setBorder(null);
        btnSalir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        getContentPane().add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(1520, 0, 30, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Banner2.png"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 140, 530));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Banner1.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1410, 150, 130, 530));

        scrlMangas.setBackground(new java.awt.Color(0, 0, 0, 80));
        scrlMangas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));

        pnlMangas.setBackground(new java.awt.Color(0, 0, 0));
        pnlMangas.setPreferredSize(new java.awt.Dimension(630, 4000));
        pnlMangas.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pnlTenkuu.setBackground(new java.awt.Color(0, 0, 0, 80));
        pnlTenkuu.setOpaque(false);
        pnlTenkuu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnTenkuu.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnTenkuu.setBorderPainted(false);
        btnTenkuu.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnTenkuu.setOpaque(false);
        btnTenkuu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTenkuuActionPerformed(evt);
            }
        });
        pnlTenkuu.add(btnTenkuu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 590, 220));

        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        txtaTenkuu.setEditable(false);
        txtaTenkuu.setColumns(20);
        txtaTenkuu.setFont(new java.awt.Font("Javanese Text", 1, 14)); // NOI18N
        txtaTenkuu.setRows(5);
        jScrollPane2.setViewportView(txtaTenkuu);

        pnlTenkuu.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 30, 420, 190));

        jLabel11.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Tenkuu Shinpan Vol.1");
        pnlTenkuu.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 0, 370, 30));

        lblTenkuu.setOpaque(true);
        pnlTenkuu.add(lblTenkuu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 140, 200));

        pnlMangas.add(pnlTenkuu, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 590, 230));

        pnlShin.setBackground(new java.awt.Color(0, 0, 0, 80));
        pnlShin.setOpaque(false);
        pnlShin.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnShin.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnShin.setBorderPainted(false);
        btnShin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnShin.setOpaque(false);
        btnShin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShinActionPerformed(evt);
            }
        });
        pnlShin.add(btnShin, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 580, 250));

        jScrollPane5.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane5.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        txtaShingeki.setEditable(false);
        txtaShingeki.setColumns(20);
        txtaShingeki.setFont(new java.awt.Font("Javanese Text", 1, 14)); // NOI18N
        txtaShingeki.setRows(5);
        jScrollPane5.setViewportView(txtaShingeki);

        pnlShin.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 40, 420, 210));

        jLabel16.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Shingeki no Kyojin Vol.33");
        pnlShin.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 380, 30));

        lblShin.setOpaque(true);
        pnlShin.add(lblShin, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 140, 200));

        pnlMangas.add(pnlShin, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, 580, 250));

        pnlTokyo.setBackground(new java.awt.Color(0, 0, 0, 80));
        pnlTokyo.setOpaque(false);
        pnlTokyo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnTokyo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnTokyo.setBorderPainted(false);
        btnTokyo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnTokyo.setOpaque(false);
        btnTokyo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTokyoActionPerformed(evt);
            }
        });
        pnlTokyo.add(btnTokyo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 240));

        jScrollPane4.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane4.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        txtaTokyo.setEditable(false);
        txtaTokyo.setColumns(20);
        txtaTokyo.setFont(new java.awt.Font("Javanese Text", 1, 14)); // NOI18N
        txtaTokyo.setRows(5);
        jScrollPane4.setViewportView(txtaTokyo);

        pnlTokyo.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, 420, 210));

        lblTokyo.setOpaque(true);
        pnlTokyo.add(lblTokyo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 140, 200));

        jLabel3.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Tokyo Ghoul Re: Vol.9");
        pnlTokyo.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 370, 30));

        pnlMangas.add(pnlTokyo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 530, 570, -1));

        pnlBlue.setBackground(new java.awt.Color(0, 0, 0, 80));
        pnlBlue.setOpaque(false);
        pnlBlue.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnBlue.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBlue.setBorderPainted(false);
        btnBlue.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnBlue.setOpaque(false);
        btnBlue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBlueActionPerformed(evt);
            }
        });
        pnlBlue.add(btnBlue, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 580, 240));

        jScrollPane7.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane7.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        txtaBlue.setEditable(false);
        txtaBlue.setColumns(20);
        txtaBlue.setFont(new java.awt.Font("Javanese Text", 1, 14)); // NOI18N
        txtaBlue.setRows(5);
        jScrollPane7.setViewportView(txtaBlue);

        pnlBlue.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, 420, 210));

        lblBlue.setOpaque(true);
        pnlBlue.add(lblBlue, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 140, 200));

        jLabel5.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Blue Lock Vol.6");
        pnlBlue.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 370, 30));

        pnlMangas.add(pnlBlue, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 790, 580, -1));

        pnlBerserk.setBackground(new java.awt.Color(0, 0, 0, 80));
        pnlBerserk.setOpaque(false);
        pnlBerserk.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnBerserk.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBerserk.setBorderPainted(false);
        btnBerserk.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnBerserk.setOpaque(false);
        btnBerserk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBerserkActionPerformed(evt);
            }
        });
        pnlBerserk.add(btnBerserk, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 240));

        jScrollPane8.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane8.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        txtaBerserk.setEditable(false);
        txtaBerserk.setColumns(20);
        txtaBerserk.setFont(new java.awt.Font("Javanese Text", 1, 14)); // NOI18N
        txtaBerserk.setRows(5);
        jScrollPane8.setViewportView(txtaBerserk);

        pnlBerserk.add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, 420, 210));

        lblBerserk.setOpaque(true);
        pnlBerserk.add(lblBerserk, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 140, 200));

        jLabel10.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Berserk Vol.37");
        pnlBerserk.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 370, 30));

        pnlMangas.add(pnlBerserk, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 1050, 570, -1));

        pnlKimetsu.setBackground(new java.awt.Color(0, 0, 0, 80));
        pnlKimetsu.setOpaque(false);
        pnlKimetsu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnKimetsu.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnKimetsu.setBorderPainted(false);
        btnKimetsu.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnKimetsu.setOpaque(false);
        btnKimetsu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKimetsuActionPerformed(evt);
            }
        });
        pnlKimetsu.add(btnKimetsu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 240));

        jScrollPane9.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane9.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        txtaKimetsu.setEditable(false);
        txtaKimetsu.setColumns(20);
        txtaKimetsu.setFont(new java.awt.Font("Javanese Text", 1, 14)); // NOI18N
        txtaKimetsu.setRows(5);
        jScrollPane9.setViewportView(txtaKimetsu);

        pnlKimetsu.add(jScrollPane9, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, 420, 210));

        lblKimetsu.setOpaque(true);
        pnlKimetsu.add(lblKimetsu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 140, 200));

        jLabel12.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Kimetsu no Yaiba Vol.8");
        pnlKimetsu.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 370, 30));

        pnlMangas.add(pnlKimetsu, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 1310, -1, -1));

        pnlShuu.setBackground(new java.awt.Color(0, 0, 0, 80));
        pnlShuu.setOpaque(false);
        pnlShuu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnShuu.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnShuu.setBorderPainted(false);
        btnShuu.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnShuu.setOpaque(false);
        btnShuu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShuuActionPerformed(evt);
            }
        });
        pnlShuu.add(btnShuu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 240));

        jScrollPane10.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane10.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        txtaShuu.setEditable(false);
        txtaShuu.setColumns(20);
        txtaShuu.setFont(new java.awt.Font("Javanese Text", 1, 14)); // NOI18N
        txtaShuu.setRows(5);
        jScrollPane10.setViewportView(txtaShuu);

        pnlShuu.add(jScrollPane10, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, 420, 210));

        lblShuu.setOpaque(true);
        pnlShuu.add(lblShuu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 140, 200));

        jLabel13.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Shuumatsu no Valkyrie Vol.14");
        pnlShuu.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 370, 30));

        pnlMangas.add(pnlShuu, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 1570, 570, -1));

        pnlOverlord.setBackground(new java.awt.Color(0, 0, 0, 80));
        pnlOverlord.setOpaque(false);
        pnlOverlord.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnOverlord.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnOverlord.setBorderPainted(false);
        btnOverlord.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnOverlord.setOpaque(false);
        btnOverlord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOverlordActionPerformed(evt);
            }
        });
        pnlOverlord.add(btnOverlord, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 240));

        jScrollPane11.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane11.setToolTipText("");
        jScrollPane11.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        txtaOverlord.setEditable(false);
        txtaOverlord.setColumns(20);
        txtaOverlord.setFont(new java.awt.Font("Javanese Text", 1, 14)); // NOI18N
        txtaOverlord.setRows(5);
        jScrollPane11.setViewportView(txtaOverlord);

        pnlOverlord.add(jScrollPane11, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, 420, 210));

        lblOverlord.setOpaque(true);
        pnlOverlord.add(lblOverlord, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 140, 200));

        jLabel14.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Overlord Vol.13");
        pnlOverlord.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 370, 30));

        pnlMangas.add(pnlOverlord, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 1830, 570, -1));

        pnlYoukoso.setBackground(new java.awt.Color(0, 0, 0, 80));
        pnlYoukoso.setOpaque(false);
        pnlYoukoso.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnYoukoso.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnYoukoso.setBorderPainted(false);
        btnYoukoso.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnYoukoso.setOpaque(false);
        btnYoukoso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnYoukosoActionPerformed(evt);
            }
        });
        pnlYoukoso.add(btnYoukoso, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 240));

        jScrollPane12.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane12.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        txtaYoukoso.setEditable(false);
        txtaYoukoso.setColumns(20);
        txtaYoukoso.setFont(new java.awt.Font("Javanese Text", 1, 14)); // NOI18N
        txtaYoukoso.setRows(5);
        jScrollPane12.setViewportView(txtaYoukoso);

        pnlYoukoso.add(jScrollPane12, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, 420, 210));

        lblYoukoso.setOpaque(true);
        pnlYoukoso.add(lblYoukoso, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 140, 200));

        jLabel15.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Youkoso Jitsuryoku Vol.6");
        pnlYoukoso.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 370, 30));

        pnlMangas.add(pnlYoukoso, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 2090, 570, -1));

        pnlBlack.setBackground(new java.awt.Color(0, 0, 0, 80));
        pnlBlack.setOpaque(false);
        pnlBlack.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnBlack.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBlack.setBorderPainted(false);
        btnBlack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnBlack.setOpaque(false);
        btnBlack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBlackActionPerformed(evt);
            }
        });
        pnlBlack.add(btnBlack, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 240));

        jScrollPane13.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane13.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        txtaBlack.setEditable(false);
        txtaBlack.setColumns(20);
        txtaBlack.setFont(new java.awt.Font("Javanese Text", 1, 14)); // NOI18N
        txtaBlack.setRows(5);
        jScrollPane13.setViewportView(txtaBlack);

        pnlBlack.add(jScrollPane13, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, 420, 210));

        lblBlack.setOpaque(true);
        pnlBlack.add(lblBlack, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 140, 200));

        jLabel17.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Black Clover Vol.24");
        pnlBlack.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 370, 30));

        pnlMangas.add(pnlBlack, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 2350, 570, -1));

        pnlOne.setBackground(new java.awt.Color(0, 0, 0, 80));
        pnlOne.setOpaque(false);
        pnlOne.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnOne.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnOne.setBorderPainted(false);
        btnOne.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnOne.setOpaque(false);
        btnOne.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOneActionPerformed(evt);
            }
        });
        pnlOne.add(btnOne, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 240));

        jScrollPane14.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane14.setToolTipText("");
        jScrollPane14.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        txtaOne.setEditable(false);
        txtaOne.setColumns(20);
        txtaOne.setFont(new java.awt.Font("Javanese Text", 1, 14)); // NOI18N
        txtaOne.setRows(5);
        jScrollPane14.setViewportView(txtaOne);

        pnlOne.add(jScrollPane14, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, 420, 210));

        lblOne.setOpaque(true);
        pnlOne.add(lblOne, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 140, 200));

        jLabel18.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("One Punch Man Vol.7");
        pnlOne.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 370, 30));

        pnlMangas.add(pnlOne, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 2610, 570, -1));

        pnlMushoku.setBackground(new java.awt.Color(0, 0, 0, 80));
        pnlMushoku.setOpaque(false);
        pnlMushoku.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnMushoku.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnMushoku.setBorderPainted(false);
        btnMushoku.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnMushoku.setOpaque(false);
        btnMushoku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMushokuActionPerformed(evt);
            }
        });
        pnlMushoku.add(btnMushoku, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 240));

        jScrollPane15.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane15.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        txtaMushoku.setEditable(false);
        txtaMushoku.setColumns(20);
        txtaMushoku.setFont(new java.awt.Font("Javanese Text", 1, 14)); // NOI18N
        txtaMushoku.setRows(5);
        jScrollPane15.setViewportView(txtaMushoku);

        pnlMushoku.add(jScrollPane15, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, 420, 210));

        lblMushoku.setOpaque(true);
        pnlMushoku.add(lblMushoku, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 140, 200));

        jLabel19.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Mushoku Tensei Vol.10");
        pnlMushoku.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 370, 30));

        pnlMangas.add(pnlMushoku, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 2870, 570, -1));

        pnlBoku.setBackground(new java.awt.Color(0, 0, 0, 80));
        pnlBoku.setOpaque(false);
        pnlBoku.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnBoku.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBoku.setBorderPainted(false);
        btnBoku.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnBoku.setOpaque(false);
        btnBoku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBokuActionPerformed(evt);
            }
        });
        pnlBoku.add(btnBoku, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 240));

        jScrollPane16.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane16.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        txtaBoku.setEditable(false);
        txtaBoku.setColumns(20);
        txtaBoku.setFont(new java.awt.Font("Javanese Text", 1, 14)); // NOI18N
        txtaBoku.setRows(5);
        jScrollPane16.setViewportView(txtaBoku);

        pnlBoku.add(jScrollPane16, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, 420, 210));

        lblBoku.setOpaque(true);
        pnlBoku.add(lblBoku, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 140, 200));

        jLabel20.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Boku no Hero Academia Vol.30");
        pnlBoku.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 370, 30));

        pnlMangas.add(pnlBoku, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 3130, 570, -1));

        pnlGoblin.setBackground(new java.awt.Color(0, 0, 0, 80));
        pnlGoblin.setOpaque(false);
        pnlGoblin.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnGoblin.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnGoblin.setBorderPainted(false);
        btnGoblin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnGoblin.setOpaque(false);
        btnGoblin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGoblinActionPerformed(evt);
            }
        });
        pnlGoblin.add(btnGoblin, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 240));

        jScrollPane17.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane17.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        txtaGoblin.setEditable(false);
        txtaGoblin.setColumns(20);
        txtaGoblin.setFont(new java.awt.Font("Javanese Text", 1, 14)); // NOI18N
        txtaGoblin.setRows(5);
        jScrollPane17.setViewportView(txtaGoblin);

        pnlGoblin.add(jScrollPane17, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, 420, 210));

        lblGoblin.setOpaque(true);
        pnlGoblin.add(lblGoblin, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 140, 200));

        jLabel21.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("Goblin Slayer Vol.11");
        pnlGoblin.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 370, 30));

        pnlMangas.add(pnlGoblin, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 3390, 570, -1));

        pnlTsuki.setBackground(new java.awt.Color(0, 0, 0, 80));
        pnlTsuki.setOpaque(false);
        pnlTsuki.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnTsuki.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnTsuki.setBorderPainted(false);
        btnTsuki.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnTsuki.setOpaque(false);
        btnTsuki.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTsukiActionPerformed(evt);
            }
        });
        pnlTsuki.add(btnTsuki, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 240));

        jScrollPane6.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane6.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        txtaTsuki.setEditable(false);
        txtaTsuki.setColumns(20);
        txtaTsuki.setFont(new java.awt.Font("Javanese Text", 1, 14)); // NOI18N
        txtaTsuki.setRows(5);
        jScrollPane6.setViewportView(txtaTsuki);

        pnlTsuki.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, 420, 210));

        lblTsuki.setOpaque(true);
        pnlTsuki.add(lblTsuki, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 140, 200));

        jLabel4.setFont(new java.awt.Font("Dialog", 3, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Tsuki ga Michibiku Vol.9");
        pnlTsuki.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 370, 30));

        pnlMangas.add(pnlTsuki, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 3650, 570, -1));

        scrlMangas.setViewportView(pnlMangas);

        getContentPane().add(scrlMangas, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 100, 650, 770));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoCat.png"))); // NOI18N
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 730, 140, 70));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoCat.png"))); // NOI18N
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(1400, 50, 140, 70));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoCat.png"))); // NOI18N
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1400, 730, 140, 70));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoCat.png"))); // NOI18N
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 140, 70));

        pnlMenu.setBackground(new java.awt.Color(0, 0, 0));
        pnlMenu.setOpaque(false);
        pnlMenu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnInicio.setBackground(new java.awt.Color(0, 0, 0));
        btnInicio.setBorder(null);
        btnInicio.setPreferredSize(new java.awt.Dimension(80, 80));
        btnInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInicioActionPerformed(evt);
            }
        });
        pnlMenu.add(btnInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 10, 80, 80));

        cboCat.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        cboCat.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Categorías", "Acción", "Artes Marciales", "Aventura", "Comedia", "Deportes", "Drama", "Escolares", "Fantasía", "Harem", "Historico", "Horror", "Magia", "Misterio", "Psicológico", "Romance", "Seinen", "Shounen", "Sobrenatural", "Superpoderes", "Suspenso", "Tragedia" }));
        cboCat.setBorder(null);
        cboCat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboCatActionPerformed(evt);
            }
        });
        pnlMenu.add(cboCat, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, 280, 40));

        btnPedido.setBackground(new java.awt.Color(0, 0, 0));
        btnPedido.setBorder(null);
        btnPedido.setPreferredSize(new java.awt.Dimension(80, 80));
        btnPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPedidoActionPerformed(evt);
            }
        });
        pnlMenu.add(btnPedido, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 10, 80, 80));

        getContentPane().add(pnlMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 0, 1260, 100));

        pnlDesc.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        pnlDesc.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblFotoM.setBackground(new java.awt.Color(0, 0, 0));
        pnlDesc.add(lblFotoM, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, 300, 420));

        lblNomM.setFont(new java.awt.Font("Segoe UI", 3, 36)); // NOI18N
        lblNomM.setForeground(new java.awt.Color(255, 255, 255));
        lblNomM.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pnlDesc.add(lblNomM, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 440, 350, 60));

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        txtaDesc.setEditable(false);
        txtaDesc.setColumns(20);
        txtaDesc.setFont(new java.awt.Font("Perpetua", 1, 14)); // NOI18N
        txtaDesc.setRows(5);
        txtaDesc.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        txtaDesc.setOpaque(false);
        jScrollPane1.setViewportView(txtaDesc);

        pnlDesc.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 520, 460, 260));

        lblFDesc.setBackground(new java.awt.Color(255, 255, 255));
        pnlDesc.add(lblFDesc, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 510, 480, 280));
        pnlDesc.add(lblFonDesc, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 560, 810));

        getContentPane().add(pnlDesc, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 60, 550, 790));

        lblFon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/FonCat.png"))); // NOI18N
        getContentPane().add(lblFon, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1550, 870));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    private void btnTenkuuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTenkuuActionPerformed
        
        pnlDesc.setVisible(true);
        lblNomM.setText("");
        txtaDesc.setText("");
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/TenkuuShinpan.jpg"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblFotoM.getWidth(),
                lblFotoM.getHeight(),Image.SCALE_DEFAULT));
        lblFotoM.setIcon(Escala);
        nomM = "Tenkuu Shinpan";
        lblNomM.setText(nomM);
        txtaDesc.setText("Yuri Honjo aparece de repente en un mundo muy extraño,\nlleno de rascacielos y"
                + " en el que no se puede bajar a la superficie.\nDespués de ver cómo un enmascarado asesina"
                + " a un hombre,\nsale corriendo para no ser la próxima víctima y acaba en la azotea,\n"
                + "donde empieza a llamar a gente con su móvil,\nsin saber qué hacer, y consigue hablar"
                + " con su hermano,\nque resulta que está en el mismo mundo que ella.\nEsto le da fuerzas:"
                + " decide que sobrevivirá y se reunirá con él.\nSin embargo,"
                + " pronto descubrirá que hay más de un \"enmascarado\".");
    }//GEN-LAST:event_btnTenkuuActionPerformed

    private void btnInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInicioActionPerformed
        // TODO add your handling code here:
        dispose();
        new frmInicio().setVisible(true);
    }//GEN-LAST:event_btnInicioActionPerformed

    private void btnTokyoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTokyoActionPerformed

        pnlDesc.setVisible(true);
        lblNomM.setText("");
        txtaDesc.setText("");
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/MTokyo.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblFotoM.getWidth(),
                lblFotoM.getHeight(),Image.SCALE_DEFAULT));
        lblFotoM.setIcon(Escala);
        nomM = "Tokyo Ghoul: Re";
        lblNomM.setText(nomM);
        txtaDesc.setText("Ciudad de Tokio, la cual sigue sumergida en la desesperación.\n"
                + "Seres devoradores de hombres misteriosos, espíritus necrófagos,\n"
                + "proliferan en Tokio. Vivir escondido es la vida cotidiana\n"
                + "de sus habitantes, la existencia de demonios,\n"
                + "cuya identidad verdadera y llena de misterio\n"
                + "aterroriza permanentemente residentes de Tokio.\n"
                + "En CCG, la única institución que investiga y resuelve los casos\n"
                + "relacionados con vampiros, se le asigna\n"
                + "un nuevo caso a Haise Sasaki.Mientras que hace frente\n"
                + "a cuatro revoltosos y problemáticos niños\n"
                + "conocidas como “Quinx”, los problemas comienzan para Haise.");
    }//GEN-LAST:event_btnTokyoActionPerformed

    private void btnShinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShinActionPerformed
        // TODO add your handling code here:
        
        pnlDesc.setVisible(true);
        lblNomM.setText("");
        txtaDesc.setText("");
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/MShingeki.jpg"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblFotoM.getWidth(),
                lblFotoM.getHeight(),Image.SCALE_DEFAULT));
        lblFotoM.setIcon(Escala);
        nomM = "Shingeki no Kyojin";
        lblNomM.setText(nomM);
        txtaDesc.setText("Un mundo donde criaturas humanoides cuyo tamaño alcanza\n"
                + "hasta lo 15m que en general parecen burlas deformes\n"
                + "de los seres humanos,devoran a los humanos\n"
                + "hasta el borde de la extinción\n"
                + "sin ningún motivo o razón aparente.\n"
                + "Los únicos supervivientes viven en un gran territorio,\n"
                + "completamente rodeado por una inmensa muralla\n"
                + "que alcanza los 50m,siendo al mismo tiempo su salvación y prisión,\n"
                + "mas allá solo hay titanes y se considera básicamente\n"
                + "un suicidio ir mas allá del gran muro..");
    }//GEN-LAST:event_btnShinActionPerformed

    private void btnTsukiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTsukiActionPerformed

        pnlDesc.setVisible(true);
        lblNomM.setText("");
        txtaDesc.setText("");
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/MTsuki.jpg"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblFotoM.getWidth(),
                lblFotoM.getHeight(),Image.SCALE_DEFAULT));
        lblFotoM.setIcon(Escala);
        nomM = "Tsuki ga Michibiku";
        lblNomM.setText(nomM);
        txtaDesc.setText("La historia de fantasía se centra en Makoto Misumi,\n"
                + "un chico ordinario de preparatoria que es enviado a un\n"
                + "nuevo mundo como un valiente guerrero. Desafortunadamente,\n"
                + "la diosa de ese nuevo mundo le dijo con desdén:\n"
                + "“Qué feo eres”, lo despojó de su título y lo desterró\n"
                + "a los confines más remotos del desierto. Mientras\n"
                + "deambulaba por la zona, Makoto se encontró con dragones,\n"
                + "arañas, orcos, enanos y todo tipo de criaturas fantásticas.\n"
                + "Debido a las diferencias en el entorno de su mundo natal,\n"
                + "Makoto ahora exhibe extraordinarios poderes mágicos\n"
                + "y de combate. Por lo tanto sobrevive en este mundo\n"
                + "mientras se enfrenta a varias amenazas.");
    }//GEN-LAST:event_btnTsukiActionPerformed

    private void btnBlueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBlueActionPerformed
        
        pnlDesc.setVisible(true);
        lblNomM.setText("");
        txtaDesc.setText("");
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/MBlue.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblFotoM.getWidth(),
                lblFotoM.getHeight(),Image.SCALE_DEFAULT));
        lblFotoM.setIcon(Escala);
        nomM = "Blue Lock";
        lblNomM.setText(nomM);
        txtaDesc.setText("Tras una desastrosa derrota en el Mundial 2018,\n"
                + "la selección de Japón lucha por recuperarse. ¿Pero qué le falta?\n"
                + "Un delantero absoluto, que pueda guiarles hacia la victoria.\n"
                + "La Asociación de Fútbol de Japón está empeñada en crear\n"
                + "un delantero con hambre de gol y sed de victoria,\n"
                + "que pueda ser el instrumento decisivo para dar la vuelta\n"
                + "a un partido perdido… y para ello ha reunido a 300\n"
                + "de los mejores y más brillantes jugadores juveniles de Japón,\n"
                + " encerrándolos en un centro conocido como “Blue Lock”.\n"
                + "¿Quién se convertirá en el líder del equipo?\n"
                + "¿Será capaz de superar a todos los que se interpongan en su camino?");
    }//GEN-LAST:event_btnBlueActionPerformed

    private void btnBerserkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBerserkActionPerformed
        
        pnlDesc.setVisible(true);
        lblNomM.setText("");
        txtaDesc.setText("");
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/MBerserk.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblFotoM.getWidth(),
                lblFotoM.getHeight(),Image.SCALE_DEFAULT));
        lblFotoM.setIcon(Escala);
        nomM = "Berserk";
        lblNomM.setText(nomM);
        txtaDesc.setText("En una época medieval oscura y violenta,\n"
                + "inmersa en una guerra que se prolonga desde hace cien años,\n"
                + "un mercenario destaca por encima de todos los demás\n"
                + "por su habilidad y su ferocidad, su nombre es Guts.\n"
                + "Durante el asedio de un castillo, Guts llama\n"
                + "la atención de Griffith, el líder de la Banda de los Halcones,\n"
                + "de la que se dice que jamás ha conocido la derrota en la batalla.\n"
                + "Tras unirse de forma reluctante al grupo,\n"
                + "Guts exhibe un valor sin precedentes para justificar\n"
                + "la confianza de Griffith y ganarse el respeto de sus compañeros.\n"
                + "Pero el sueño de Griffith va más allá de acumular oro y riqueza,\n"
                + "lo que más desea en su corazón es convertirse en Rey.\n"
                + "Guts se compromete ayudarle a cumplir con su destino sin\n"
                + "conocer los sacrificios que deberá realizar.");
    }//GEN-LAST:event_btnBerserkActionPerformed

    private void btnKimetsuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKimetsuActionPerformed
        
        pnlDesc.setVisible(true);
        lblNomM.setText("");
        txtaDesc.setText("");
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/MKimetsu.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblFotoM.getWidth(),
                lblFotoM.getHeight(),Image.SCALE_DEFAULT));
        lblFotoM.setIcon(Escala);
        nomM = "Kimetsu no Yaiba";
        lblNomM.setText(nomM);
        txtaDesc.setText("El protagonista de la historia es Kamado Tanjiro,\n"
                + "un joven que tiene un gran corazón, pero que también presume\n"
                + "sobrada inteligencia. Su historia resulta conmovedora porque\n"
                + "se dedica a la venta de carbón para sobrevivir al \n"
                + "lado de su familia.Sin embargo, la tragedia toca a su\n"
                + "puerta cuando sus seres queridos son asesinatos.\n"
                + "El culpable es Oni, un demonio sanguinario.\n"
                + "Su hermana Nezuko, quien también sobrevivió al ataque,\n"
                + "fue convertida en un peligroso ser que con\n"
                + "características sobrenaturales.Así es como Tanjiro\n"
                + "busca transformarse en un asesino de demonios,\n"
                + "con la intención de vengar a su familia\n y recuperar a su hermana.");
    }//GEN-LAST:event_btnKimetsuActionPerformed

    private void btnShuuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShuuActionPerformed
        
        pnlDesc.setVisible(true);
        lblNomM.setText("");
        txtaDesc.setText("");
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/MShuumatsu.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblFotoM.getWidth(),
                lblFotoM.getHeight(),Image.SCALE_DEFAULT));
        lblFotoM.setIcon(Escala);
        nomM = "Shuumatsu no Valkyrie";
        lblNomM.setText(nomM);
        txtaDesc.setText("¡La humanidad está condenada! Los dioses de todas\n"
                + "las religiones se reúnen cada 1.000 años en el Valhalla\n"
                + "para decidir el destino de la raza humana. Esta vez la\n"
                + "humanidad ha llegado demasiado lejos: guerras, contaminación,\n"
                + "destrucción de la naturaleza… La decisión de los dioses\n"
                + "está tomada, los humanos se extinguirán…\n"
                + "Pero hay una última esperanza: las valkirias proponen\n"
                + "que se active una antigua ley que permite el enfrentamiento\n"
                + "de los dioses con los humanos más poderosos, el Ragnarök.\n"
                + "Cada facción elegirá a sus 13 contendientes y tendrán que\n"
                + "enfrentarse en un desigual combate que sólo puede tener un\n"
                + "ganador y que se decidirá al mejor de siete.");
    }//GEN-LAST:event_btnShuuActionPerformed

    private void btnOverlordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOverlordActionPerformed
        
        pnlDesc.setVisible(true);
        lblNomM.setText("");
        txtaDesc.setText("");
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/MOverlord.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblFotoM.getWidth(),
                lblFotoM.getHeight(),Image.SCALE_DEFAULT));
        lblFotoM.setIcon(Escala);
        nomM = "Olverlord";
        lblNomM.setText(nomM);
        txtaDesc.setText("La historia comienza con Yggdrasil, un MMORPG\n"
                + "popular cuyo servidor fue apagado. Sin embargo,\n"
                + "el protagonista Momonga, cuyo personaje es un mago poderoso,\n"
                + "decide no salir del juego. El avatar de Momonga\n"
                + "se transforma en un esqueleto. A pesar del apagón,\n"
                + "el mundo sigue adelante, con personajes\n"
                + "no jugadores (NPC) que empiezan a sentir emociones y\n"
                + "viven sus vidas según sus deseos. Al no tener padres,\n"
                + "amigos, o un lugar en la sociedad, este joven ordinario\n"
                + "se esfuerza por hacerse cargo de este nuevo mundo virtual.");
    }//GEN-LAST:event_btnOverlordActionPerformed

    private void btnYoukosoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnYoukosoActionPerformed
        
        pnlDesc.setVisible(true);
        lblNomM.setText("");
        txtaDesc.setText("");
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/MYoukoso.jpeg"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblFotoM.getWidth(),
                lblFotoM.getHeight(),Image.SCALE_DEFAULT));
        lblFotoM.setIcon(Escala);
        nomM = "Youkoso Jitsuryoku";
        lblNomM.setText(nomM);
        txtaDesc.setText("Kiyotaka Ayanokouji acaba de entrar en la Academia\n"
                + "Tokyo Koudo Ikusei, de la cual se dice que el 100%\n"
                + "de sus estudiantes acaban yendo a la universidad\n"
                + "o encontrando un buen trabajo. Sin embargo nuestro\n"
                + "protagonista acaba en la Clase 1-D, donde la escuela\n"
                + "pone a todos los alumnos con problemas. Y lo que es más,\n"
                + "cada mes la escuela otorga a los estudiantes puntos\n"
                + "por valor de 100.000 yenes, y las clases emplean un\n"
                + "sistema por el cual se puede hablar, dormir e incluso\n"
                + "molestar a los compañeros durante las clases.");
    }//GEN-LAST:event_btnYoukosoActionPerformed

    private void btnBlackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBlackActionPerformed
        
        pnlDesc.setVisible(true);
        lblNomM.setText("");
        txtaDesc.setText("");
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/MBlack.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblFotoM.getWidth(),
                lblFotoM.getHeight(),Image.SCALE_DEFAULT));
        lblFotoM.setIcon(Escala);
        nomM = "Black Clover";
        lblNomM.setText(nomM);
        txtaDesc.setText("La historia de Black Clover nos pone en la piel\n"
                + "de un joven llamado Asta, el cual quiere convertirse\n"
                + " en el mago más grande del reino. Sin embargo,\n"
                + "hay un inconveniente: ¡no puede usar magia! Por suerte,\n"
                + "Asta recibe el grimorio trébol de cinco hojas,\n"
                + "que le otorga el poder de la anti-magia.\n"
                + "¿Puede alguien carente de magia convertirse\n"
                + "en el Rey Hechicero? Una cosa está clara,\n"
                + "Asta nunca se rendirá.");
    }//GEN-LAST:event_btnBlackActionPerformed

    private void btnOneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOneActionPerformed
        
        pnlDesc.setVisible(true);
        lblNomM.setText("");
        txtaDesc.setText("");
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/MOne.jpg"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblFotoM.getWidth(),
                lblFotoM.getHeight(),Image.SCALE_DEFAULT));
        lblFotoM.setIcon(Escala);
        nomM = "One Punch Man";
        lblNomM.setText(nomM);
        txtaDesc.setText("La historia tiene lugar en una de las metrópolis\n"
                + "de ficción de la Tierra, la ciudad Z en Japón.\n"
                + "El mundo está lleno de extraños monstruos que\n"
                + "misteriosamente aparecen y causan muchos desastres.\n"
                + "Saitama, el protagonista, es un poderoso superhéroe\n"
                + "que derrota fácilmente a los monstruos u otros\n"
                + "villanos con un único golpe. Debido a esto Saitama\n"
                + "ha encontrado aburrida su fuerza y siempre está tratando\n"
                + "de encontrar rivales más poderosos que le pueden igualar.");
    }//GEN-LAST:event_btnOneActionPerformed

    private void btnMushokuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMushokuActionPerformed
        
        pnlDesc.setVisible(true);
        lblNomM.setText("");
        txtaDesc.setText("");
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/MMushoku.jpg"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblFotoM.getWidth(),
                lblFotoM.getHeight(),Image.SCALE_DEFAULT));
        lblFotoM.setIcon(Escala);
        nomM = "Mushoku Tensei";
        lblNomM.setText(nomM);
        txtaDesc.setText("Un Otaku de 34 años de edad es expulsado de su casa\n"
                + "por su familia por ser un «nini». Poco atractivo y sin dinero,\n"
                + "descubre que ha llegado a un callejón sin salida en su vida y\n"
                + "se da cuenta de que su vida podría haber sido mucho mejor de haber\n"
                + "tomado mejores decisiones en el pasado. Justo cuando estaba en\n"
                + "un punto de arrepentimiento, vio un camión que circulaba a gran\n"
                + "velocidad hacia tres estudiantes de secundaria en su camino.\n"
                + "Reuniendo toda la fuerza que tenía, trató de salvarlos pero\n"
                + "terminó siendo atropellado por el camión, acabando por perder la vida.\n"
                + "La siguiente vez que abrió los ojos ya estaba reencarnado en un mundo\n"
                + "de espadas y magia llamado Rudeus Greyrat. Nacido en un mundo nuevo,\n"
                + "con una vida nueva, Rudeus decide que «¡Esta vez, realmente\n"
                + "viviré mi vida al máximo sin ningún arrepentimiento!» Así,\n"
                + "comienza el viaje de un hombre anhelando reiniciar su vida.");
    }//GEN-LAST:event_btnMushokuActionPerformed

    private void btnBokuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBokuActionPerformed
        
        pnlDesc.setVisible(true);
        lblNomM.setText("");
        txtaDesc.setText("");
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/MBoku.jpg"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblFotoM.getWidth(),
                lblFotoM.getHeight(),Image.SCALE_DEFAULT));
        lblFotoM.setIcon(Escala);
        nomM = "Boku no Hero Academia";
        lblNomM.setText(nomM);
        txtaDesc.setText("Uno de los grandes deseos de Izuku es conocer a un\n"
                + "legendario héroe llamado All Might, egrsado con honores\n"
                + "de la U.A (una academia capacitada para instruir a\n"
                + "poderosos héroes que puedan ser capaces de defender\n"
                + "al mundo de toda maldad y peligro). Un buen día, Izuku\n"
                + "realiza su mayor sueño de conocer a su ídolo hasta el\n"
                + "punto de emocionarse. All, al ver la buena disposición\n"
                + "de Midoriya, le promete que le facultará de\n"
                + "superpoderes para ser un héroe más.");
    }//GEN-LAST:event_btnBokuActionPerformed

    private void btnGoblinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGoblinActionPerformed
        
        pnlDesc.setVisible(true);
        lblNomM.setText("");
        txtaDesc.setText("");
        Cromo = new ImageIcon(getClass().getResource("/Imagenes/MGoblin.png"));
        Escala = new ImageIcon(Cromo.getImage().getScaledInstance(lblFotoM.getWidth(),
                lblFotoM.getHeight(),Image.SCALE_DEFAULT));
        lblFotoM.setIcon(Escala);
        nomM = "Goblin Slayer";
        lblNomM.setText(nomM);
        txtaDesc.setText("Todo comienza cuando una joven Sacerdotisa recién salida\n"
                + "del templo decide unirse a un grupo de novatos para una misión\n"
                + "aparentemente sencilla: eliminar goblins, seres repulsivos\n"
                + "pero con el tamaño y la fuerza de un niño humano. Después de todo,\n"
                + "encargarse de unos goblins de pacotilla aunque seas principiante\n"
                + "no puede ser tan difícil, ¿no?. En un mundo donde las misiones\n"
                + "superarriesgadas y los monstruos desaforados se toman a la ligera,\n"
                + "las masacres de personas con poca preparación están a la orden del día.\n"
                + "En sólo unos minutos, el equipo es masacrado salvajemente\n"
                + "y a la Sacerdotisa la salva en el último momento Goblin Slayer,\n"
                + "un experimentado aventurero de rango plata que está obsesionado\n"
                + "con aniquilar a esa raza, y así se inicia una incómoda alianza\n"
                + "entre ambos. Desde aquí, la historia sigue a la Sacerdotisa y\n"
                + "a otros aventureros que se van sumando al Goblin Slayer en\n"
                + "su misión de erradicar a todos los goblins del planeta.");
    }//GEN-LAST:event_btnGoblinActionPerformed

    private void cboCatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboCatActionPerformed
        
        
        switch(cboCat.getSelectedItem().toString())
        {
            case "Acción":pnlTenkuu.setVisible(true);pnlShin.setVisible(false);pnlTokyo.setVisible(true);
                          pnlBlue.setVisible(false);pnlBerserk.setVisible(true);pnlKimetsu.setVisible(true);
                          pnlShuu.setVisible(true);pnlOverlord.setVisible(true);pnlYoukoso.setVisible(false);
                          pnlBlack.setVisible(true);pnlMushoku.setVisible(true);pnlOne.setVisible(true);
                          pnlBoku.setVisible(true);pnlGoblin.setVisible(true);pnlTsuki.setVisible(true);
                          break;
            case "Artes Marciales":pnlTenkuu.setVisible(false);pnlShin.setVisible(false);pnlTokyo.setVisible(false);
                          pnlBlue.setVisible(false);pnlBerserk.setVisible(false);pnlKimetsu.setVisible(false);
                          pnlShuu.setVisible(true);pnlOverlord.setVisible(false);pnlYoukoso.setVisible(false);
                          pnlBlack.setVisible(false);pnlMushoku.setVisible(false);pnlOne.setVisible(false);
                          pnlBoku.setVisible(false);pnlGoblin.setVisible(false);pnlTsuki.setVisible(false);
                          break;
            case "Aventura":pnlTenkuu.setVisible(false);pnlShin.setVisible(false);pnlTokyo.setVisible(false);
                          pnlBlue.setVisible(false);pnlBerserk.setVisible(true);pnlKimetsu.setVisible(false);
                          pnlShuu.setVisible(false);pnlOverlord.setVisible(true);pnlYoukoso.setVisible(false);
                          pnlBlack.setVisible(false);pnlMushoku.setVisible(true);pnlOne.setVisible(false);
                          pnlBoku.setVisible(false);pnlGoblin.setVisible(true);pnlTsuki.setVisible(true);
                          break;
            case "Comedia":pnlTenkuu.setVisible(false);pnlShin.setVisible(false);pnlTokyo.setVisible(false);
                          pnlBlue.setVisible(false);pnlBerserk.setVisible(false);pnlKimetsu.setVisible(false);
                          pnlShuu.setVisible(false);pnlOverlord.setVisible(true);pnlYoukoso.setVisible(false);
                          pnlBlack.setVisible(true);pnlMushoku.setVisible(true);pnlOne.setVisible(true);
                          pnlBoku.setVisible(true);pnlGoblin.setVisible(false);pnlTsuki.setVisible(true);
                          break;
            case "Deportes":pnlTenkuu.setVisible(false);pnlShin.setVisible(false);pnlTokyo.setVisible(false);
                          pnlBlue.setVisible(true);pnlBerserk.setVisible(false);pnlKimetsu.setVisible(false);
                          pnlShuu.setVisible(false);pnlOverlord.setVisible(false);pnlYoukoso.setVisible(false);
                          pnlBlack.setVisible(false);pnlMushoku.setVisible(false);pnlOne.setVisible(false);
                          pnlBoku.setVisible(false);pnlGoblin.setVisible(false);pnlTsuki.setVisible(false);
                          break;
            case "Drama":pnlTenkuu.setVisible(true);pnlShin.setVisible(true);pnlTokyo.setVisible(true);
                          pnlBlue.setVisible(false);pnlBerserk.setVisible(true);pnlKimetsu.setVisible(false);
                          pnlShuu.setVisible(false);pnlOverlord.setVisible(false);pnlYoukoso.setVisible(true);
                          pnlBlack.setVisible(false);pnlMushoku.setVisible(false);pnlOne.setVisible(false);
                          pnlBoku.setVisible(false);pnlGoblin.setVisible(true);pnlTsuki.setVisible(false);
                          break;
            case "Escolares":pnlTenkuu.setVisible(false);pnlShin.setVisible(false);pnlTokyo.setVisible(false);
                          pnlBlue.setVisible(false);pnlBerserk.setVisible(false);pnlKimetsu.setVisible(true);
                          pnlShuu.setVisible(false);pnlOverlord.setVisible(false);pnlYoukoso.setVisible(true);
                          pnlBlack.setVisible(false);pnlMushoku.setVisible(false);pnlOne.setVisible(false);
                          pnlBoku.setVisible(true);pnlGoblin.setVisible(false);pnlTsuki.setVisible(false);
                          break;
            case "Fantasía":pnlTenkuu.setVisible(false);pnlShin.setVisible(false);pnlTokyo.setVisible(false);
                          pnlBlue.setVisible(false);pnlBerserk.setVisible(true);pnlKimetsu.setVisible(false);
                          pnlShuu.setVisible(true);pnlOverlord.setVisible(true);pnlYoukoso.setVisible(false);
                          pnlBlack.setVisible(true);pnlMushoku.setVisible(true);pnlOne.setVisible(false);
                          pnlBoku.setVisible(false);pnlGoblin.setVisible(true);pnlTsuki.setVisible(true);
                          break;
            case "Harem":pnlTenkuu.setVisible(false);pnlShin.setVisible(false);pnlTokyo.setVisible(false);
                          pnlBlue.setVisible(false);pnlBerserk.setVisible(false);pnlKimetsu.setVisible(false);
                          pnlShuu.setVisible(false);pnlOverlord.setVisible(false);pnlYoukoso.setVisible(false);
                          pnlBlack.setVisible(false);pnlMushoku.setVisible(true);pnlOne.setVisible(false);
                          pnlBoku.setVisible(false);pnlGoblin.setVisible(false);pnlTsuki.setVisible(true);
                          break;
            case "Historico":pnlTenkuu.setVisible(false);pnlShin.setVisible(false);pnlTokyo.setVisible(false);
                          pnlBlue.setVisible(false);pnlBerserk.setVisible(false);pnlKimetsu.setVisible(false);
                          pnlShuu.setVisible(true);pnlOverlord.setVisible(false);pnlYoukoso.setVisible(false);
                          pnlBlack.setVisible(false);pnlMushoku.setVisible(false);pnlOne.setVisible(false);
                          pnlBoku.setVisible(false);pnlGoblin.setVisible(false);pnlTsuki.setVisible(false);
                          break;
            case "Horror":pnlTenkuu.setVisible(true);pnlShin.setVisible(true);pnlTokyo.setVisible(true);
                          pnlBlue.setVisible(false);pnlBerserk.setVisible(true);pnlKimetsu.setVisible(false);
                          pnlShuu.setVisible(false);pnlOverlord.setVisible(false);pnlYoukoso.setVisible(false);
                          pnlBlack.setVisible(false);pnlMushoku.setVisible(false);pnlOne.setVisible(false);
                          pnlBoku.setVisible(false);pnlGoblin.setVisible(true);pnlTsuki.setVisible(false);
                          break;
            case "Magia":pnlTenkuu.setVisible(false);pnlShin.setVisible(false);pnlTokyo.setVisible(false);
                          pnlBlue.setVisible(false);pnlBerserk.setVisible(false);pnlKimetsu.setVisible(false);
                          pnlShuu.setVisible(false);pnlOverlord.setVisible(false);pnlYoukoso.setVisible(false);
                          pnlBlack.setVisible(true);pnlMushoku.setVisible(true);pnlOne.setVisible(false);
                          pnlBoku.setVisible(false);pnlGoblin.setVisible(false);pnlTsuki.setVisible(false);
                          break;
            case "Misterio":pnlTenkuu.setVisible(true);pnlShin.setVisible(false);pnlTokyo.setVisible(true);
                          pnlBlue.setVisible(false);pnlBerserk.setVisible(false);pnlKimetsu.setVisible(false);
                          pnlShuu.setVisible(false);pnlOverlord.setVisible(false);pnlYoukoso.setVisible(false);
                          pnlBlack.setVisible(false);pnlMushoku.setVisible(false);pnlOne.setVisible(false);
                          pnlBoku.setVisible(false);pnlGoblin.setVisible(false);pnlTsuki.setVisible(false);
                          break;
            case "Psicológico":pnlTenkuu.setVisible(false);pnlShin.setVisible(false);pnlTokyo.setVisible(true);
                          pnlBlue.setVisible(false);pnlBerserk.setVisible(true);pnlKimetsu.setVisible(false);
                          pnlShuu.setVisible(false);pnlOverlord.setVisible(false);pnlYoukoso.setVisible(true);
                          pnlBlack.setVisible(false);pnlMushoku.setVisible(false);pnlOne.setVisible(false);
                          pnlBoku.setVisible(false);pnlGoblin.setVisible(false);pnlTsuki.setVisible(false);
                          break;
            case "Romance":pnlTenkuu.setVisible(false);pnlShin.setVisible(false);pnlTokyo.setVisible(false);
                          pnlBlue.setVisible(false);pnlBerserk.setVisible(false);pnlKimetsu.setVisible(false);
                          pnlShuu.setVisible(false);pnlOverlord.setVisible(false);pnlYoukoso.setVisible(false);
                          pnlBlack.setVisible(false);pnlMushoku.setVisible(true);pnlOne.setVisible(false);
                          pnlBoku.setVisible(false);pnlGoblin.setVisible(false);pnlTsuki.setVisible(true);
                          break;
            case "Seinen":pnlTenkuu.setVisible(false);pnlShin.setVisible(false);pnlTokyo.setVisible(false);
                          pnlBlue.setVisible(false);pnlBerserk.setVisible(false);pnlKimetsu.setVisible(false);
                          pnlShuu.setVisible(false);pnlOverlord.setVisible(false);pnlYoukoso.setVisible(false);
                          pnlBlack.setVisible(false);pnlMushoku.setVisible(false);pnlOne.setVisible(true);
                          pnlBoku.setVisible(false);pnlGoblin.setVisible(true);pnlTsuki.setVisible(false);
                          break;
            case "Shounen":pnlTenkuu.setVisible(true);pnlShin.setVisible(true);pnlTokyo.setVisible(false);
                          pnlBlue.setVisible(true);pnlBerserk.setVisible(true);pnlKimetsu.setVisible(true);
                          pnlShuu.setVisible(false);pnlOverlord.setVisible(false);pnlYoukoso.setVisible(false);
                          pnlBlack.setVisible(true);pnlMushoku.setVisible(false);pnlOne.setVisible(false);
                          pnlBoku.setVisible(true);pnlGoblin.setVisible(false);pnlTsuki.setVisible(true);
                          break;
            case "Sobrenatural":pnlTenkuu.setVisible(false);pnlShin.setVisible(false);pnlTokyo.setVisible(true);
                          pnlBlue.setVisible(false);pnlBerserk.setVisible(true);pnlKimetsu.setVisible(true);
                          pnlShuu.setVisible(true);pnlOverlord.setVisible(true);pnlYoukoso.setVisible(false);
                          pnlBlack.setVisible(false);pnlMushoku.setVisible(false);pnlOne.setVisible(true);
                          pnlBoku.setVisible(false);pnlGoblin.setVisible(false);pnlTsuki.setVisible(false);
                          break;
            case "Superpoderes":pnlTenkuu.setVisible(false);pnlShin.setVisible(false);pnlTokyo.setVisible(false);
                          pnlBlue.setVisible(false);pnlBerserk.setVisible(false);pnlKimetsu.setVisible(false);
                          pnlShuu.setVisible(false);pnlOverlord.setVisible(false);pnlYoukoso.setVisible(false);
                          pnlBlack.setVisible(false);pnlMushoku.setVisible(false);pnlOne.setVisible(true);
                          pnlBoku.setVisible(true);pnlGoblin.setVisible(false);pnlTsuki.setVisible(false);
                          break;
            case "Suspenso":pnlTenkuu.setVisible(false);pnlShin.setVisible(false);pnlTokyo.setVisible(false);
                          pnlBlue.setVisible(false);pnlBerserk.setVisible(false);pnlKimetsu.setVisible(false);
                          pnlShuu.setVisible(false);pnlOverlord.setVisible(false);pnlYoukoso.setVisible(true);
                          pnlBlack.setVisible(false);pnlMushoku.setVisible(false);pnlOne.setVisible(false);
                          pnlBoku.setVisible(false);pnlGoblin.setVisible(false);pnlTsuki.setVisible(false);
                          break;
            case "Tragedia":pnlTenkuu.setVisible(false);pnlShin.setVisible(false);pnlTokyo.setVisible(false);
                          pnlBlue.setVisible(false);pnlBerserk.setVisible(true);pnlKimetsu.setVisible(false);
                          pnlShuu.setVisible(false);pnlOverlord.setVisible(false);pnlYoukoso.setVisible(false);
                          pnlBlack.setVisible(false);pnlMushoku.setVisible(false);pnlOne.setVisible(false);
                          pnlBoku.setVisible(false);pnlGoblin.setVisible(false);pnlTsuki.setVisible(false);
                          break;
            case "Categorías":pnlTenkuu.setVisible(true);pnlShin.setVisible(true);pnlTokyo.setVisible(true);
                          pnlBlue.setVisible(true);pnlBerserk.setVisible(true);pnlKimetsu.setVisible(true);
                          pnlShuu.setVisible(true);pnlOverlord.setVisible(true);pnlYoukoso.setVisible(true);
                          pnlBlack.setVisible(true);pnlMushoku.setVisible(true);pnlOne.setVisible(true);
                          pnlBoku.setVisible(true);pnlGoblin.setVisible(true);pnlTsuki.setVisible(true);
        }
    }//GEN-LAST:event_cboCatActionPerformed

    private void btnPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPedidoActionPerformed
        dispose();
        new frmPedido().setVisible(true);
    }//GEN-LAST:event_btnPedidoActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnSalirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmCatalogo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmCatalogo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmCatalogo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmCatalogo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmCatalogo().setVisible(true);
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBerserk;
    private javax.swing.JButton btnBlack;
    private javax.swing.JButton btnBlue;
    private javax.swing.JButton btnBoku;
    private javax.swing.JButton btnGoblin;
    private javax.swing.JButton btnInicio;
    private javax.swing.JButton btnKimetsu;
    private javax.swing.JButton btnMushoku;
    private javax.swing.JButton btnOne;
    private javax.swing.JButton btnOverlord;
    private javax.swing.JButton btnPedido;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton btnShin;
    private javax.swing.JButton btnShuu;
    private javax.swing.JButton btnTenkuu;
    private javax.swing.JButton btnTokyo;
    private javax.swing.JButton btnTsuki;
    private javax.swing.JButton btnYoukoso;
    private javax.swing.JComboBox<String> cboCat;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane16;
    private javax.swing.JScrollPane jScrollPane17;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JLabel lblBerserk;
    private javax.swing.JLabel lblBlack;
    private javax.swing.JLabel lblBlue;
    private javax.swing.JLabel lblBoku;
    private javax.swing.JLabel lblFDesc;
    private javax.swing.JLabel lblFon;
    private javax.swing.JLabel lblFonDesc;
    private javax.swing.JLabel lblFotoM;
    private javax.swing.JLabel lblGoblin;
    private javax.swing.JLabel lblKimetsu;
    private javax.swing.JLabel lblMushoku;
    private javax.swing.JLabel lblNomM;
    private javax.swing.JLabel lblOne;
    private javax.swing.JLabel lblOverlord;
    private javax.swing.JLabel lblShin;
    private javax.swing.JLabel lblShuu;
    private javax.swing.JLabel lblTenkuu;
    private javax.swing.JLabel lblTokyo;
    private javax.swing.JLabel lblTsuki;
    private javax.swing.JLabel lblYoukoso;
    private javax.swing.JPanel pnlBerserk;
    private javax.swing.JPanel pnlBlack;
    private javax.swing.JPanel pnlBlue;
    private javax.swing.JPanel pnlBoku;
    private javax.swing.JPanel pnlDesc;
    private javax.swing.JPanel pnlGoblin;
    private javax.swing.JPanel pnlKimetsu;
    private javax.swing.JPanel pnlMangas;
    private javax.swing.JPanel pnlMenu;
    private javax.swing.JPanel pnlMushoku;
    private javax.swing.JPanel pnlOne;
    private javax.swing.JPanel pnlOverlord;
    private javax.swing.JPanel pnlShin;
    private javax.swing.JPanel pnlShuu;
    private javax.swing.JPanel pnlTenkuu;
    private javax.swing.JPanel pnlTokyo;
    private javax.swing.JPanel pnlTsuki;
    private javax.swing.JPanel pnlYoukoso;
    private javax.swing.JScrollPane scrlMangas;
    private javax.swing.JTextArea txtaBerserk;
    private javax.swing.JTextArea txtaBlack;
    private javax.swing.JTextArea txtaBlue;
    private javax.swing.JTextArea txtaBoku;
    private javax.swing.JTextArea txtaDesc;
    private javax.swing.JTextArea txtaGoblin;
    private javax.swing.JTextArea txtaKimetsu;
    private javax.swing.JTextArea txtaMushoku;
    private javax.swing.JTextArea txtaOne;
    private javax.swing.JTextArea txtaOverlord;
    private javax.swing.JTextArea txtaShingeki;
    private javax.swing.JTextArea txtaShuu;
    private javax.swing.JTextArea txtaTenkuu;
    private javax.swing.JTextArea txtaTokyo;
    private javax.swing.JTextArea txtaTsuki;
    private javax.swing.JTextArea txtaYoukoso;
    // End of variables declaration//GEN-END:variables
}
